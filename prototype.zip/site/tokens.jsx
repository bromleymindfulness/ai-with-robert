// Tokens + shared primitives for the Robert Mitchell site
// Direction B — all-mono technical document
// Defaults live in TWEAK_DEFAULTS block so they're persistable via __edit_mode_set_keys

const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "accent": "#3a6ea5",
  "ink": "#0b1620",
  "paper": "#eef1f4",
  "panel": "#ffffff",
  "displayFont": "JetBrains Mono",
  "monoFont": "JetBrains Mono",
  "heroVariant": "standard",
  "servicesLayout": "list",
  "darkMode": false,
  "heroHeadline": "A team of AI marketing specialists, deployed to your Telegram.",
  "heroSub": "Content · Ads · SEO · Email · Analytics. Each with its own expertise, memory, and access to your tools. 24/7 — for less than a junior hire.",
  "ctaLabel": "Save seat"
}/*EDITMODE-END*/;

// Palette presets (all editorial blue/blue-grey family)
const PALETTES = {
  'slate':    { accent: '#3a6ea5', ink: '#0b1620', paper: '#eef1f4', panel: '#ffffff' },
  'ink':      { accent: '#2d4f7a', ink: '#0a1420', paper: '#f3f4f6', panel: '#ffffff' },
  'bluegray': { accent: '#4a7aa8', ink: '#1a2634', paper: '#e9edf2', panel: '#fafbfc' },
  'cold':     { accent: '#4e83b8', ink: '#0d1826', paper: '#e3e8ee', panel: '#ffffff' },
  'dark':     { accent: '#6fa3d9', ink: '#e8edf3', paper: '#0b1620', panel: '#111e2c' },
};

// Tokens used across every component
function useTokens(t) {
  return React.useMemo(() => ({
    accent: t.accent,
    ink: t.ink,
    paper: t.paper,
    panel: t.panel,
    muted: t.darkMode ? 'rgba(232,237,243,0.55)' : 'rgba(11,22,32,0.55)',
    subtle: t.darkMode ? 'rgba(232,237,243,0.75)' : 'rgba(11,22,32,0.75)',
    rule: t.darkMode ? 'rgba(232,237,243,0.14)' : 'rgba(11,22,32,0.13)',
    hairline: t.darkMode ? 'rgba(232,237,243,0.08)' : 'rgba(11,22,32,0.07)',
    display: `"${t.displayFont}", ui-monospace, "SF Mono", monospace`,
    mono: `"${t.monoFont}", ui-monospace, "SF Mono", monospace`,
    sans: `"Geist", -apple-system, BlinkMacSystemFont, system-ui, sans-serif`,
  }), [t.accent, t.ink, t.paper, t.panel, t.darkMode, t.displayFont, t.monoFont]);
}

// ─── Mono label (ticks / category markers) ───
function Tick({ children, color, size = 10, style }) {
  return (
    <span style={{
      fontFamily: 'var(--mono)', fontSize: size, letterSpacing: 1.4,
      textTransform: 'uppercase', color: color || 'var(--muted)',
      fontWeight: 500, ...style,
    }}>{children}</span>
  );
}

// ─── Section number / heading ───
function SectionHeader({ num, label, right }) {
  return (
    <div style={{
      display: 'flex', justifyContent: 'space-between',
      padding: '0 0 18px', marginBottom: 4,
    }}>
      <Tick>§ {num} — {label}</Tick>
      {right && <Tick>{right}</Tick>}
    </div>
  );
}

// ─── Row with label/value and hairline ───
function SpecRow({ l, r, href, onClick }) {
  const clickable = !!(href || onClick);
  return (
    <div
      onClick={onClick}
      style={{
        display: 'grid', gridTemplateColumns: '1fr auto', alignItems: 'baseline',
        padding: '14px 0',
        borderBottom: '1px solid var(--rule)',
        cursor: clickable ? 'pointer' : 'default',
        transition: 'opacity 120ms',
      }}
      onMouseEnter={e => clickable && (e.currentTarget.style.opacity = '0.6')}
      onMouseLeave={e => clickable && (e.currentTarget.style.opacity = '1')}
    >
      <Tick style={{ color: 'var(--muted)' }}>{l}</Tick>
      <span style={{
        fontFamily: 'var(--mono)', fontSize: 13, color: 'var(--ink)',
      }}>{r}</span>
    </div>
  );
}

// ─── Inverted block (the dark CTA) ───
function InvertBlock({ children, style }) {
  return (
    <div style={{
      background: 'var(--ink)', color: 'var(--paper)',
      padding: 'clamp(22px, 4vw, 32px)',
      ...style,
    }}>{children}</div>
  );
}

// ─── Underlined text input (editorial style) ───
function UnderlineInput({ value, onChange, placeholder, inverted, onSubmit, cta = 'Send →' }) {
  const [focus, setFocus] = React.useState(false);
  const borderColor = inverted ? 'var(--paper)' : 'var(--ink)';
  return (
    <div style={{
      display: 'flex', alignItems: 'stretch',
      borderBottom: `1px solid ${focus ? 'var(--accent)' : borderColor}`,
      transition: 'border-color 150ms',
    }}>
      <input
        type="email"
        value={value}
        placeholder={placeholder}
        onChange={e => onChange(e.target.value)}
        onFocus={() => setFocus(true)}
        onBlur={() => setFocus(false)}
        onKeyDown={e => e.key === 'Enter' && onSubmit && onSubmit()}
        style={{
          flex: 1, border: 'none', background: 'transparent',
          padding: '10px 0', fontSize: 16,
          color: inverted ? 'var(--paper)' : 'var(--ink)',
          fontFamily: 'var(--sans)', outline: 'none',
          minWidth: 0,
        }}
      />
      <button
        type="button"
        onClick={onSubmit}
        style={{
          border: 'none', background: 'transparent',
          fontFamily: 'var(--mono)', fontSize: 11, letterSpacing: 1.4,
          textTransform: 'uppercase', fontWeight: 500,
          color: inverted ? 'var(--paper)' : 'var(--ink)',
          padding: '0 4px', cursor: 'pointer', whiteSpace: 'nowrap',
        }}
      >{cta}</button>
    </div>
  );
}

// ─── Mono text link ───
function TextLink({ children, onClick, href, color }) {
  return (
    <a
      href={href || '#'}
      onClick={e => { if (onClick) { e.preventDefault(); onClick(); } }}
      style={{
        fontFamily: 'var(--mono)', fontSize: 11, letterSpacing: 1.4,
        textTransform: 'uppercase', textDecoration: 'none',
        color: color || 'var(--ink)', fontWeight: 500,
        display: 'inline-flex', alignItems: 'center', gap: 6,
        cursor: 'pointer',
      }}
    >{children}</a>
  );
}

// ─── Live pulse dot ───
function Pulse({ color }) {
  return (
    <span style={{ position: 'relative', width: 7, height: 7, display: 'inline-block' }}>
      <span style={{
        position: 'absolute', inset: 0, borderRadius: '50%',
        background: color || 'var(--accent)',
      }}/>
      <span style={{
        position: 'absolute', inset: -3, borderRadius: '50%',
        background: color || 'var(--accent)',
        opacity: 0.35,
        animation: 'rmpulse 1.6s ease-out infinite',
      }}/>
    </span>
  );
}

Object.assign(window, {
  TWEAK_DEFAULTS, PALETTES, useTokens,
  Tick, SectionHeader, SpecRow, InvertBlock,
  UnderlineInput, TextLink, Pulse,
});
