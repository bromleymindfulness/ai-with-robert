// Direction A — Editorial Masthead
// Newsreader display serif headline, JetBrains Mono meta, generous whitespace
// Feels like a thoughtful publication front page

function DirectionA({ width = 390 }) {
  const ink = '#0d1b2a';
  const paper = '#f6f4ef';
  const blue = '#2a4d7a';
  const muted = '#6b7785';
  const rule = 'rgba(13,27,42,0.12)';

  return (
    <div style={{
      width, minHeight: 844,
      background: paper, color: ink,
      fontFamily: '"Geist", -apple-system, system-ui, sans-serif',
      fontSize: 15, lineHeight: 1.5,
      position: 'relative',
    }}>
      {/* Masthead */}
      <div style={{
        padding: '18px 22px', borderBottom: `1px solid ${rule}`,
        display: 'flex', justifyContent: 'space-between', alignItems: 'center',
        fontFamily: '"JetBrains Mono", monospace', fontSize: 11,
        letterSpacing: 0.2, textTransform: 'uppercase', color: muted,
      }}>
        <span>№ 001 · Vol I</span>
        <span>Mon 20 Apr 2026</span>
      </div>

      {/* Wordmark */}
      <div style={{
        padding: '28px 22px 14px', borderBottom: `1px solid ${rule}`,
      }}>
        <div style={{
          fontFamily: '"Instrument Serif", serif',
          fontSize: 44, lineHeight: 0.95, letterSpacing: -1.5,
          fontStyle: 'italic', color: ink,
        }}>
          Robert<br/>Mitchell
        </div>
        <div style={{
          marginTop: 10,
          fontFamily: '"JetBrains Mono", monospace', fontSize: 10,
          letterSpacing: 1.2, textTransform: 'uppercase', color: muted,
        }}>
          AI Marketing Automation · Training
        </div>
      </div>

      {/* Lede */}
      <div style={{ padding: '28px 22px 24px' }}>
        <div style={{
          fontFamily: '"JetBrains Mono", monospace', fontSize: 10,
          letterSpacing: 1.4, textTransform: 'uppercase', color: blue,
          marginBottom: 14,
        }}>
          ▸ This week's live class
        </div>
        <h1 style={{
          fontFamily: '"Instrument Serif", serif',
          fontSize: 38, lineHeight: 1.02, letterSpacing: -1,
          fontWeight: 400, margin: 0, textWrap: 'pretty',
        }}>
          A team of AI specialists, deployed to your Telegram.
        </h1>
        <p style={{
          marginTop: 20, fontSize: 16, lineHeight: 1.55, color: '#2a3642',
          textWrap: 'pretty',
        }}>
          Content, ads, SEO, email, analytics — each with its own expertise,
          memory, and access to your tools. Running 24/7 for less than a
          junior hire.
        </p>
      </div>

      {/* Email capture inline */}
      <div style={{
        margin: '0 22px', padding: '20px 0 22px',
        borderTop: `1px solid ${rule}`, borderBottom: `1px solid ${rule}`,
      }}>
        <div style={{
          fontFamily: '"JetBrains Mono", monospace', fontSize: 10,
          letterSpacing: 1.4, textTransform: 'uppercase', color: muted,
          marginBottom: 10,
        }}>
          Next live · Thu 23 Apr · 18:00 GMT
        </div>
        <div style={{
          display: 'flex', alignItems: 'stretch',
          borderBottom: `1px solid ${ink}`,
        }}>
          <input
            placeholder="you@domain.com"
            style={{
              flex: 1, border: 'none', background: 'transparent',
              padding: '10px 0', fontSize: 16, color: ink,
              fontFamily: 'inherit', outline: 'none',
            }}
          />
          <button style={{
            border: 'none', background: 'transparent',
            fontFamily: '"JetBrains Mono", monospace', fontSize: 11,
            letterSpacing: 1.4, textTransform: 'uppercase', color: ink,
            padding: '0 4px', cursor: 'pointer',
          }}>
            Save seat ↗
          </button>
        </div>
      </div>

      {/* Services — two columns */}
      <div style={{
        padding: '28px 22px', display: 'grid',
        gridTemplateColumns: '1fr 1fr', gap: 22,
        borderBottom: `1px solid ${rule}`,
      }}>
        {[
          { n: '01', t: 'Training', d: 'Learn to build & deploy bot teams.' },
          { n: '02', t: 'Automation', d: 'We deploy & run the bots for you.' },
        ].map(s => (
          <div key={s.n}>
            <div style={{
              fontFamily: '"JetBrains Mono", monospace', fontSize: 10,
              letterSpacing: 1.2, color: blue, marginBottom: 8,
            }}>{s.n}</div>
            <div style={{
              fontFamily: '"Instrument Serif", serif', fontSize: 22,
              lineHeight: 1.1, marginBottom: 6,
            }}>{s.t}</div>
            <div style={{ fontSize: 13, color: muted, lineHeight: 1.45 }}>
              {s.d}
            </div>
          </div>
        ))}
      </div>

      {/* Latest writing */}
      <div style={{ padding: '24px 22px 20px' }}>
        <div style={{
          display: 'flex', justifyContent: 'space-between',
          fontFamily: '"JetBrains Mono", monospace', fontSize: 10,
          letterSpacing: 1.4, textTransform: 'uppercase', color: muted,
          marginBottom: 16,
        }}>
          <span>From the blog</span>
          <span>All →</span>
        </div>

        {[
          { t: 'Why 20 small bots beat one big agent', d: '6 min · Apr 18' },
          { t: 'The Telegram-first marketing stack', d: '9 min · Apr 11' },
          { t: 'Memory, tools, and the cost of context', d: '5 min · Apr 04' },
        ].map((p, i) => (
          <div key={i} style={{
            padding: '14px 0',
            borderTop: i === 0 ? `1px solid ${rule}` : 'none',
            borderBottom: `1px solid ${rule}`,
          }}>
            <div style={{
              fontFamily: '"Instrument Serif", serif', fontSize: 20,
              lineHeight: 1.15, letterSpacing: -0.3, textWrap: 'pretty',
            }}>{p.t}</div>
            <div style={{
              marginTop: 6,
              fontFamily: '"JetBrains Mono", monospace', fontSize: 10,
              letterSpacing: 1, color: muted, textTransform: 'uppercase',
            }}>{p.d}</div>
          </div>
        ))}
      </div>

      {/* Footer */}
      <div style={{
        padding: '22px', marginTop: 12,
        fontFamily: '"JetBrains Mono", monospace', fontSize: 10,
        letterSpacing: 1.2, textTransform: 'uppercase', color: muted,
        display: 'flex', justifyContent: 'space-between',
      }}>
        <span>Telegram</span>
        <span>YouTube</span>
        <span>Contact</span>
      </div>
    </div>
  );
}

window.DirectionA = DirectionA;
