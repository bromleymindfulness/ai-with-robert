// Direction B — Index / Document
// All-mono typography, hairline rules, everything feels like a technical document
// Dense but calm. One accent. Very cutting-edge minimalist.

function DirectionB({ width = 390 }) {
  const ink = '#0b1620';
  const paper = '#eef1f4';
  const blue = '#3a6ea5';
  const muted = '#7a8794';
  const rule = 'rgba(11,22,32,0.15)';

  const Row = ({ l, r, big }) => (
    <div style={{
      display: 'flex', justifyContent: 'space-between',
      padding: big ? '16px 0' : '11px 0',
      borderBottom: `1px solid ${rule}`,
      fontSize: big ? 14 : 12,
      fontFamily: '"JetBrains Mono", monospace',
      letterSpacing: big ? 0 : 0.3,
      color: ink,
    }}>
      <span style={{ color: muted, textTransform: 'uppercase', fontSize: 10, letterSpacing: 1.2 }}>{l}</span>
      <span style={{ textAlign: 'right' }}>{r}</span>
    </div>
  );

  return (
    <div style={{
      width, minHeight: 844, background: paper, color: ink,
      fontFamily: '"JetBrains Mono", monospace', fontSize: 13,
    }}>
      {/* Header bar */}
      <div style={{
        padding: '14px 20px', borderBottom: `1px solid ${rule}`,
        display: 'flex', justifyContent: 'space-between', alignItems: 'center',
        fontSize: 11, letterSpacing: 1.4, textTransform: 'uppercase',
      }}>
        <span style={{ fontWeight: 600 }}>R. MITCHELL</span>
        <span style={{
          display: 'inline-flex', alignItems: 'center', gap: 6, color: blue,
        }}>
          <span style={{
            width: 6, height: 6, borderRadius: '50%', background: blue,
          }}/> LIVE THU
        </span>
      </div>

      {/* Title block */}
      <div style={{ padding: '48px 20px 40px' }}>
        <div style={{ fontSize: 10, letterSpacing: 1.4, color: muted, textTransform: 'uppercase', marginBottom: 20 }}>
          Document / 001 / Services
        </div>
        <div style={{
          fontSize: 28, lineHeight: 1.25, letterSpacing: -0.3,
          fontWeight: 400, textWrap: 'balance',
        }}>
          A team of AI marketing<br/>specialists, deployed<br/>to your Telegram.
        </div>
        <div style={{ marginTop: 20, fontSize: 12, color: muted, lineHeight: 1.6 }}>
          Content · Ads · SEO · Email · Analytics.<br/>
          Each with its own expertise, memory,<br/>
          and access to your tools. 24/7.
        </div>
      </div>

      {/* Spec table */}
      <div style={{ padding: '0 20px', borderTop: `1px solid ${rule}` }}>
        <Row l="Client" r="You"/>
        <Row l="Bots" r="20 / server"/>
        <Row l="Channel" r="Telegram"/>
        <Row l="Uptime" r="24 / 7"/>
        <Row l="Cost" r="< 1 junior hire"/>
      </div>

      {/* Services */}
      <div style={{ padding: '40px 20px 20px' }}>
        <div style={{ fontSize: 10, letterSpacing: 1.4, color: muted, textTransform: 'uppercase', marginBottom: 14 }}>
          § 02 — Services
        </div>
        {[
          ['A', 'AI Automation Training', 'Build your own bot team'],
          ['B', 'AI Marketing Automation', 'We deploy & operate it'],
        ].map(([k, t, d]) => (
          <div key={k} style={{
            padding: '18px 0', borderTop: `1px solid ${rule}`,
            display: 'grid', gridTemplateColumns: '24px 1fr auto', gap: 12,
            alignItems: 'baseline',
          }}>
            <span style={{ color: blue }}>{k}</span>
            <div>
              <div style={{ fontSize: 14, marginBottom: 3 }}>{t}</div>
              <div style={{ fontSize: 11, color: muted }}>{d}</div>
            </div>
            <span style={{ color: muted }}>→</span>
          </div>
        ))}
      </div>

      {/* Live class CTA */}
      <div style={{
        margin: '20px', padding: '22px 18px', background: ink, color: paper,
      }}>
        <div style={{ fontSize: 10, letterSpacing: 1.4, color: '#8aa5c4', textTransform: 'uppercase', marginBottom: 12 }}>
          Next live · YouTube
        </div>
        <div style={{ fontSize: 18, lineHeight: 1.3, marginBottom: 18, fontFamily: '"Instrument Serif", serif', letterSpacing: -0.2 }}>
          "Deploying your first<br/>Telegram bot team"
        </div>
        <div style={{ display: 'flex', gap: 8, fontSize: 10, letterSpacing: 1.4, textTransform: 'uppercase', color: '#8aa5c4', marginBottom: 18 }}>
          <span>Thu 23 Apr</span><span>·</span><span>18:00 GMT</span>
        </div>
        <div style={{
          display: 'flex', borderBottom: `1px solid ${paper}`, paddingBottom: 8,
        }}>
          <input placeholder="email" style={{
            flex: 1, background: 'transparent', border: 'none', color: paper,
            fontFamily: 'inherit', fontSize: 14, outline: 'none',
          }}/>
          <span style={{ fontSize: 11, letterSpacing: 1.2, textTransform: 'uppercase' }}>Notify me →</span>
        </div>
      </div>

      {/* Index */}
      <div style={{ padding: '20px', borderTop: `1px solid ${rule}` }}>
        <div style={{ fontSize: 10, letterSpacing: 1.4, color: muted, textTransform: 'uppercase', marginBottom: 14 }}>
          § 03 — Writing
        </div>
        {[
          ['0.1', '20 small bots vs 1 big agent', 'Apr 18'],
          ['0.2', 'Telegram-first marketing', 'Apr 11'],
          ['0.3', 'Memory, tools, context', 'Apr 04'],
        ].map(([n, t, d], i) => (
          <div key={i} style={{
            display: 'grid', gridTemplateColumns: '36px 1fr auto', gap: 12,
            padding: '13px 0', borderTop: `1px solid ${rule}`,
            fontSize: 13,
          }}>
            <span style={{ color: blue }}>{n}</span>
            <span>{t}</span>
            <span style={{ color: muted, fontSize: 11 }}>{d}</span>
          </div>
        ))}
      </div>

      <div style={{
        padding: 20, fontSize: 10, letterSpacing: 1.4, color: muted,
        textTransform: 'uppercase', display: 'flex', justifyContent: 'space-between',
        borderTop: `1px solid ${rule}`,
      }}>
        <span>Telegram ↗</span><span>YouTube ↗</span><span>Contact ↗</span>
      </div>
    </div>
  );
}

window.DirectionB = DirectionB;
