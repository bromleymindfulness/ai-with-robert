// Top bar + footer — appear on every "page"

function TopBar({ route, onRoute, live }) {
  const [open, setOpen] = React.useState(false);
  const nav = [
    ['home', 'Index'],
    ['services', 'Services'],
    ['classes', 'Classes'],
    ['writing', 'Writing'],
    ['about', 'About'],
    ['contact', 'Contact'],
  ];
  return (
    <div style={{
      position: 'sticky', top: 0, zIndex: 50,
      background: 'var(--paper)',
      borderBottom: '1px solid var(--rule)',
    }}>
      {/* Live bar — only when the class is imminent */}
      {live && (
        <div style={{
          background: 'var(--ink)', color: 'var(--paper)',
          padding: '7px 20px', display: 'flex', alignItems: 'center', gap: 10,
          fontFamily: 'var(--mono)', fontSize: 10, letterSpacing: 1.4,
          textTransform: 'uppercase',
        }}>
          <Pulse color="#ff6159"/>
          <span>Live on YouTube · "Deploying your first Telegram bot team"</span>
          <span style={{ marginLeft: 'auto', opacity: 0.7 }}>Watch →</span>
        </div>
      )}

      <div style={{
        padding: '14px 20px', display: 'flex',
        justifyContent: 'space-between', alignItems: 'center',
      }}>
        <a
          href="#"
          onClick={e => { e.preventDefault(); onRoute('home'); setOpen(false); }}
          style={{
            fontFamily: 'var(--mono)', fontSize: 11, letterSpacing: 1.4,
            textTransform: 'uppercase', fontWeight: 600, color: 'var(--ink)',
            textDecoration: 'none', display: 'inline-flex', alignItems: 'center', gap: 8,
          }}
        >
          <span style={{
            width: 10, height: 10, background: 'var(--accent)',
            display: 'inline-block',
          }}/>
          R. Mitchell
        </a>

        {/* Desktop nav */}
        <nav className="rm-desktop-nav" style={{ display: 'none', gap: 26 }}>
          {nav.map(([k, l]) => (
            <a key={k}
              href="#"
              onClick={e => { e.preventDefault(); onRoute(k); }}
              style={{
                fontFamily: 'var(--mono)', fontSize: 11, letterSpacing: 1.4,
                textTransform: 'uppercase', textDecoration: 'none', fontWeight: 500,
                color: route === k ? 'var(--accent)' : 'var(--ink)',
                borderBottom: route === k ? '1px solid var(--accent)' : '1px solid transparent',
                paddingBottom: 2,
              }}
            >{l}</a>
          ))}
        </nav>

        {/* Mobile toggle */}
        <button
          className="rm-mobile-toggle"
          onClick={() => setOpen(o => !o)}
          aria-label="Menu"
          style={{
            background: 'transparent', border: `1px solid var(--rule)`,
            padding: '7px 11px', fontFamily: 'var(--mono)', fontSize: 10,
            letterSpacing: 1.4, textTransform: 'uppercase', color: 'var(--ink)',
            cursor: 'pointer', fontWeight: 500,
          }}
        >{open ? 'Close' : 'Menu'}</button>
      </div>

      {open && (
        <div style={{
          padding: '6px 20px 18px', borderTop: '1px solid var(--rule)',
        }}>
          {nav.map(([k, l]) => (
            <a key={k}
              href="#"
              onClick={e => { e.preventDefault(); onRoute(k); setOpen(false); }}
              style={{
                display: 'flex', justifyContent: 'space-between',
                padding: '14px 0', borderBottom: '1px solid var(--hairline)',
                fontFamily: 'var(--mono)', fontSize: 13, letterSpacing: 0.6,
                textTransform: 'uppercase', textDecoration: 'none', fontWeight: 500,
                color: route === k ? 'var(--accent)' : 'var(--ink)',
              }}
            >
              <span>{l}</span>
              <span style={{ fontSize: 10, opacity: 0.5 }}>0{nav.findIndex(n => n[0]===k)+1}</span>
            </a>
          ))}
        </div>
      )}
    </div>
  );
}

function Footer({ onRoute }) {
  return (
    <footer style={{
      borderTop: '1px solid var(--rule)',
      padding: 'clamp(32px, 6vw, 60px) clamp(20px, 4vw, 56px) 28px',
      background: 'var(--paper)',
    }}>
      <div style={{
        display: 'grid', gap: 'clamp(28px, 5vw, 48px)',
        gridTemplateColumns: 'minmax(0, 1fr)',
      }} className="rm-footer-grid">
        {/* Mark */}
        <div>
          <div style={{
            fontFamily: 'var(--display)', fontSize: 'clamp(32px, 8vw, 48px)',
            lineHeight: 0.95, letterSpacing: -2, fontWeight: 500,
            textTransform: 'uppercase',
            color: 'var(--ink)', marginBottom: 14,
          }}>
            Robert<br/>Mitchell
          </div>
          <Tick>AI Marketing Automation · Training</Tick>
        </div>

        {/* Links */}
        <div style={{
          display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 24,
          alignContent: 'start',
        }}>
          <div>
            <Tick style={{ color: 'var(--muted)', display: 'block', marginBottom: 14 }}>Site</Tick>
            {[['home','Index'],['services','Services'],['classes','Classes'],['writing','Writing']].map(([k,l]) => (
              <a key={k} href="#" onClick={e => { e.preventDefault(); onRoute(k); }} style={{
                display: 'block', padding: '6px 0', fontFamily: 'var(--mono)',
                fontSize: 12, letterSpacing: 0.3, textDecoration: 'none',
                color: 'var(--ink)',
              }}>{l}</a>
            ))}
          </div>
          <div>
            <Tick style={{ color: 'var(--muted)', display: 'block', marginBottom: 14 }}>Elsewhere</Tick>
            {['Telegram ↗', 'YouTube ↗', 'RSS ↗'].map(l => (
              <a key={l} href="#" style={{
                display: 'block', padding: '6px 0', fontFamily: 'var(--mono)',
                fontSize: 12, letterSpacing: 0.3, textDecoration: 'none',
                color: 'var(--ink)',
              }}>{l}</a>
            ))}
          </div>
        </div>
      </div>

      <div style={{
        display: 'flex', justifyContent: 'space-between', marginTop: 40,
        paddingTop: 18, borderTop: '1px solid var(--rule)',
        fontFamily: 'var(--mono)', fontSize: 10, letterSpacing: 1.4,
        textTransform: 'uppercase', color: 'var(--muted)',
      }}>
        <span>© 2026 R.M.</span>
        <span>Built in Astro · Netlify</span>
      </div>
    </footer>
  );
}

Object.assign(window, { TopBar, Footer });
