// Classes + Writing + About + Contact — all-mono

function Classes({ tokens, tweaks, onRoute }) {
  const [email, setEmail] = React.useState('');
  const [captured, setCaptured] = React.useState(false);
  const submit = () => { if (/.+@.+\..+/.test(email)) setCaptured(true); };

  return (
    <>
      <section style={{ padding: 'clamp(48px, 8vw, 84px) clamp(20px, 4vw, 56px) clamp(28px, 4vw, 40px)' }}>
        <Tick style={{ marginBottom: 24, display: 'block' }}>Document / 003 / Classes</Tick>
        <h1 style={{
          fontFamily: 'var(--display)', fontSize: 'clamp(32px, 5.5vw, 64px)',
          lineHeight: 1.0, letterSpacing: '-0.04em', fontWeight: 500, margin: 0,
          textTransform: 'uppercase', color: 'var(--ink)', textWrap: 'balance',
        }}>
          Live on<br/>YouTube.
        </h1>
        <p style={{
          marginTop: 24, fontFamily: 'var(--sans)',
          fontSize: 'clamp(15px, 1.6vw, 18px)', lineHeight: 1.55,
          color: 'var(--subtle)', maxWidth: 560, textWrap: 'pretty',
        }}>
          One class a week. Sixty minutes, no filler, written up
          straight after so you can skim or scroll.
        </p>
      </section>

      {/* Embed placeholder */}
      <section style={{ padding: '0 clamp(20px, 4vw, 56px) clamp(36px, 5vw, 56px)' }}>
        <div style={{
          aspectRatio: '16 / 9', width: '100%',
          background: 'var(--ink)', color: 'var(--paper)',
          display: 'grid', placeItems: 'center', position: 'relative',
          overflow: 'hidden',
        }}>
          <div style={{
            position: 'absolute', inset: 0,
            backgroundImage: 'repeating-linear-gradient(135deg, rgba(255,255,255,0.03) 0 2px, transparent 2px 14px)',
          }}/>
          <div style={{ textAlign: 'center', position: 'relative', padding: '0 24px' }}>
            <div style={{
              display: 'inline-flex', alignItems: 'center', gap: 10,
              marginBottom: 14,
            }}>
              <Pulse color="#ff6159"/>
              <Tick color="rgba(255,255,255,0.7)">YouTube Live · Thu 18:00 GMT</Tick>
            </div>
            <div style={{
              fontFamily: 'var(--display)',
              fontSize: 'clamp(18px, 2.4vw, 28px)', lineHeight: 1.15,
              letterSpacing: '-0.03em', fontWeight: 500, textTransform: 'uppercase',
              maxWidth: 520, textWrap: 'balance',
            }}>
              Embed · Upcoming class preview
            </div>
          </div>
        </div>
      </section>

      {/* Upcoming */}
      <section style={{ padding: '0 clamp(20px, 4vw, 56px) clamp(36px, 5vw, 56px)' }}>
        <SectionHeader num="A" label="Upcoming" right={`${UPCOMING_CLASSES.length} scheduled`}/>
        {UPCOMING_CLASSES.map(c => (
          <div key={c.id} style={{
            display: 'grid',
            gridTemplateColumns: 'clamp(44px, 6vw, 72px) 1fr auto',
            gap: 'clamp(12px, 2vw, 24px)',
            alignItems: 'start',
            padding: 'clamp(20px, 3vw, 26px) 0',
            borderTop: '1px solid var(--rule)',
          }}>
            <Tick color="var(--accent)">{c.num}</Tick>
            <div>
              <div style={{
                fontFamily: 'var(--display)',
                fontSize: 'clamp(17px, 2vw, 22px)',
                lineHeight: 1.2, letterSpacing: '-0.03em', fontWeight: 500,
                textTransform: 'uppercase',
                color: 'var(--ink)', marginBottom: 10, textWrap: 'balance',
              }}>{c.title}</div>
              <div style={{
                fontFamily: 'var(--sans)', fontSize: 14, lineHeight: 1.5,
                color: 'var(--subtle)', maxWidth: 520, textWrap: 'pretty',
                marginBottom: 10,
              }}>{c.abstract}</div>
              <div style={{ display: 'flex', gap: 16, flexWrap: 'wrap' }}>
                <Tick>{c.date}</Tick>
                <Tick>·</Tick>
                <Tick>{c.duration}</Tick>
              </div>
            </div>
            <TextLink color="var(--accent)">RSVP →</TextLink>
          </div>
        ))}
        <div style={{ borderTop: '1px solid var(--rule)' }}/>
      </section>

      {/* Notify */}
      <section style={{ padding: '0 clamp(20px, 4vw, 56px) clamp(36px, 5vw, 56px)' }}>
        <InvertBlock style={{ padding: 'clamp(28px, 4vw, 40px)' }}>
          <Tick color="rgba(255,255,255,0.6)">Never miss one</Tick>
          <div style={{
            fontFamily: 'var(--display)',
            fontSize: 'clamp(20px, 2.6vw, 28px)', lineHeight: 1.15,
            letterSpacing: '-0.03em', fontWeight: 500, textTransform: 'uppercase',
            margin: '12px 0 22px', maxWidth: 520, textWrap: 'balance',
          }}>
            Get a calendar invite<br/>every Monday.
          </div>
          {captured ? (
            <Tick color="var(--paper)">✓ You'll hear from me. — R.</Tick>
          ) : (
            <div style={{ maxWidth: 460 }}>
              <UnderlineInput value={email} onChange={setEmail}
                placeholder="you@domain.com" inverted onSubmit={submit}
                cta="Notify me →"/>
            </div>
          )}
        </InvertBlock>
      </section>

      {/* Past */}
      <section style={{ padding: '0 clamp(20px, 4vw, 56px) clamp(40px, 7vw, 72px)' }}>
        <SectionHeader num="B" label="Archive" right="All past classes →"/>
        {PAST_CLASSES.map(c => (
          <div key={c.id} style={{
            display: 'grid',
            gridTemplateColumns: 'clamp(44px, 6vw, 72px) 1fr auto auto',
            gap: 'clamp(10px, 2vw, 20px)',
            padding: '16px 0', borderTop: '1px solid var(--rule)',
            alignItems: 'baseline',
          }}>
            <Tick color="var(--accent)">{c.num}</Tick>
            <span style={{
              fontFamily: 'var(--sans)', fontSize: 15, color: 'var(--ink)',
              lineHeight: 1.3,
            }}>{c.title}</span>
            <Tick>{c.dateShort}</Tick>
            <Tick>▶ {c.duration}</Tick>
          </div>
        ))}
        <div style={{ borderTop: '1px solid var(--rule)' }}/>
      </section>
    </>
  );
}

function Writing({ tokens, tweaks, onRoute }) {
  const [filter, setFilter] = React.useState('All');
  const tags = ['All', 'Essay', 'Playbook', 'Note'];
  const filtered = filter === 'All' ? POSTS : POSTS.filter(p => p.tag === filter);

  return (
    <>
      <section style={{ padding: 'clamp(48px, 8vw, 84px) clamp(20px, 4vw, 56px) clamp(28px, 4vw, 40px)' }}>
        <Tick style={{ marginBottom: 24, display: 'block' }}>Document / 004 / Writing</Tick>
        <h1 style={{
          fontFamily: 'var(--display)', fontSize: 'clamp(32px, 5.5vw, 64px)',
          lineHeight: 1.0, letterSpacing: '-0.04em', fontWeight: 500, margin: 0,
          textTransform: 'uppercase', color: 'var(--ink)', textWrap: 'balance',
        }}>
          Written<br/>versions.
        </h1>
        <p style={{
          marginTop: 24, fontFamily: 'var(--sans)',
          fontSize: 'clamp(15px, 1.6vw, 18px)', lineHeight: 1.55,
          color: 'var(--subtle)', maxWidth: 560, textWrap: 'pretty',
        }}>
          Every class becomes a written post. Skim the index, or
          filter by type.
        </p>
      </section>

      {/* Filters */}
      <section style={{
        padding: '0 clamp(20px, 4vw, 56px) 20px',
        display: 'flex', gap: 0, flexWrap: 'wrap',
        borderBottom: '1px solid var(--rule)',
      }}>
        {tags.map(t => (
          <button key={t} onClick={() => setFilter(t)} style={{
            background: 'transparent', border: 'none',
            padding: '10px 16px 10px 0', marginRight: 8,
            fontFamily: 'var(--mono)', fontSize: 11, letterSpacing: 1.4,
            textTransform: 'uppercase', cursor: 'pointer', fontWeight: 500,
            color: filter === t ? 'var(--accent)' : 'var(--muted)',
            borderBottom: filter === t ? '1px solid var(--accent)' : '1px solid transparent',
            marginBottom: -1,
          }}>{t}</button>
        ))}
      </section>

      {/* Index */}
      <section style={{ padding: '0 clamp(20px, 4vw, 56px) clamp(40px, 7vw, 72px)' }}>
        {filtered.map(p => (
          <a key={p.id} href="#" onClick={e => e.preventDefault()} style={{
            display: 'grid',
            gridTemplateColumns: 'clamp(48px, 6vw, 72px) 1fr auto',
            gap: 'clamp(12px, 2vw, 24px)',
            padding: 'clamp(18px, 2.5vw, 22px) 0',
            borderBottom: '1px solid var(--rule)',
            alignItems: 'baseline', textDecoration: 'none', color: 'inherit',
            transition: 'padding-left 160ms',
          }}
            onMouseEnter={e => e.currentTarget.style.paddingLeft = '10px'}
            onMouseLeave={e => e.currentTarget.style.paddingLeft = '0'}
          >
            <Tick color="var(--accent)">{p.num}</Tick>
            <div>
              <div style={{ marginBottom: 10 }}>
                <Tick style={{ color: 'var(--muted)' }}>{p.tag}</Tick>
              </div>
              <div style={{
                fontFamily: 'var(--display)',
                fontSize: 'clamp(17px, 2vw, 22px)',
                lineHeight: 1.2, letterSpacing: '-0.03em', fontWeight: 500,
                textTransform: 'uppercase', color: 'var(--ink)',
                marginBottom: 10, textWrap: 'balance',
              }}>{p.title}</div>
              <div style={{
                fontFamily: 'var(--sans)', fontSize: 14, color: 'var(--subtle)',
                lineHeight: 1.5, maxWidth: 540, textWrap: 'pretty',
              }}>{p.excerpt}</div>
            </div>
            <div style={{ textAlign: 'right' }}>
              <Tick style={{ display: 'block' }}>{p.date}</Tick>
              <Tick style={{ display: 'block', marginTop: 6, color: 'var(--muted)' }}>{p.read}</Tick>
            </div>
          </a>
        ))}
      </section>
    </>
  );
}

function About({ tokens, tweaks }) {
  return (
    <>
      <section style={{ padding: 'clamp(48px, 8vw, 84px) clamp(20px, 4vw, 56px) clamp(28px, 4vw, 40px)' }}>
        <Tick style={{ marginBottom: 24, display: 'block' }}>Document / 005 / About</Tick>
        <h1 style={{
          fontFamily: 'var(--display)', fontSize: 'clamp(32px, 5.5vw, 64px)',
          lineHeight: 1.0, letterSpacing: '-0.04em', fontWeight: 500, margin: 0,
          textTransform: 'uppercase', color: 'var(--ink)', textWrap: 'balance',
        }}>
          Robert Mitchell,<br/>in plain prose.
        </h1>
      </section>

      <section style={{
        padding: '0 clamp(20px, 4vw, 56px) clamp(36px, 6vw, 60px)',
        display: 'grid',
        gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))',
        gap: 'clamp(24px, 3vw, 40px)',
        borderTop: '1px solid var(--rule)',
        paddingTop: 'clamp(28px, 4vw, 40px)',
      }}>
        <div style={{
          fontFamily: 'var(--sans)', fontSize: 'clamp(15px, 1.6vw, 17px)',
          lineHeight: 1.65, color: 'var(--subtle)', textWrap: 'pretty',
        }}>
          <p style={{ marginTop: 0 }}>
            I run a small fleet of twenty chatbots on a Nanoclaw server.
            They talk to each other, and they talk to me, over Telegram.
            Together they do everything a small marketing team would do —
            only twenty-four hours a day, and without meetings.
          </p>
          <p>
            I teach other people to build the same thing. Every Thursday
            on YouTube, live. Afterwards I write it up so you can skim
            it on your phone.
          </p>
          <p>
            I work with a handful of clients at a time. If that's you,
            we'll mostly meet in Telegram.
          </p>
        </div>

        <div>
          <div style={{
            aspectRatio: '4 / 5', background: 'var(--panel)',
            border: '1px solid var(--rule)',
            position: 'relative', overflow: 'hidden',
          }}>
            <div style={{
              position: 'absolute', inset: 0,
              backgroundImage: 'repeating-linear-gradient(45deg, rgba(11,22,32,0.05) 0 1px, transparent 1px 12px)',
            }}/>
            <div style={{
              position: 'absolute', inset: 0, display: 'grid', placeItems: 'center',
            }}>
              <Tick>Portrait · replace</Tick>
            </div>
          </div>
        </div>
      </section>

      {/* Fleet spec */}
      <section style={{ padding: '0 clamp(20px, 4vw, 56px) clamp(40px, 7vw, 72px)' }}>
        <SectionHeader num="A" label="Fleet" right="Nanoclaw · Apr 2026"/>
        <SpecRow l="Server"          r="Nanoclaw · 1U"/>
        <SpecRow l="Bot count"       r="20, active"/>
        <SpecRow l="Channels"        r="Telegram"/>
        <SpecRow l="Specialisms"     r="Content · Ads · SEO · Email · Analytics"/>
        <SpecRow l="Replication"     r="Tomorrow, if needed"/>
        <SpecRow l="Uptime target"   r="99.5%"/>
      </section>
    </>
  );
}

function Contact({ tokens, tweaks }) {
  const [form, setForm] = React.useState({ name: '', email: '', topic: 'training', note: '' });
  const [sent, setSent] = React.useState(false);

  const update = (k, v) => setForm(f => ({ ...f, [k]: v }));
  const valid = form.name.trim() && /.+@.+\..+/.test(form.email) && form.note.trim().length > 4;

  return (
    <>
      <section style={{ padding: 'clamp(48px, 8vw, 84px) clamp(20px, 4vw, 56px) clamp(28px, 4vw, 40px)' }}>
        <Tick style={{ marginBottom: 24, display: 'block' }}>Document / 006 / Contact</Tick>
        <h1 style={{
          fontFamily: 'var(--display)', fontSize: 'clamp(32px, 5.5vw, 64px)',
          lineHeight: 1.0, letterSpacing: '-0.04em', fontWeight: 500, margin: 0,
          textTransform: 'uppercase', color: 'var(--ink)', textWrap: 'balance',
        }}>
          Start a<br/>conversation.
        </h1>
        <p style={{
          marginTop: 24, fontFamily: 'var(--sans)',
          fontSize: 'clamp(15px, 1.6vw, 18px)', lineHeight: 1.55,
          color: 'var(--subtle)', maxWidth: 520, textWrap: 'pretty',
        }}>
          The fastest route is Telegram. The form works too —
          I reply within one business day.
        </p>
      </section>

      <section style={{
        padding: '0 clamp(20px, 4vw, 56px) clamp(40px, 7vw, 72px)',
        display: 'grid',
        gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))',
        gap: 'clamp(24px, 3vw, 48px)',
      }}>
        {/* Channels */}
        <div style={{ borderTop: '1px solid var(--rule)', paddingTop: 24 }}>
          <SectionHeader num="A" label="Channels"/>
          <SpecRow l="Telegram"  r="@robertmitchell"/>
          <SpecRow l="Email"     r="hi@robertmitchell.co"/>
          <SpecRow l="YouTube"   r="/@robertmitchell"/>
          <SpecRow l="Location"  r="London, UK"/>
        </div>

        {/* Form */}
        <div style={{ borderTop: '1px solid var(--rule)', paddingTop: 24 }}>
          <SectionHeader num="B" label="Form"/>
          {sent ? (
            <div style={{
              padding: '32px 0', borderBottom: '1px solid var(--rule)',
              fontFamily: 'var(--display)', fontSize: 'clamp(18px, 2.2vw, 24px)',
              lineHeight: 1.2, fontWeight: 500, letterSpacing: '-0.03em',
              textTransform: 'uppercase',
              color: 'var(--ink)', textWrap: 'balance',
            }}>
              Message received.<br/>
              <span style={{ color: 'var(--accent)' }}>Reply on the way.</span>
            </div>
          ) : (
            <div>
              <FormField label="Name" value={form.name} onChange={v => update('name', v)}/>
              <FormField label="Email" type="email" value={form.email} onChange={v => update('email', v)}/>
              <div style={{
                padding: '14px 0', borderBottom: '1px solid var(--rule)',
                display: 'grid', gridTemplateColumns: '80px 1fr', alignItems: 'center',
              }}>
                <Tick>Topic</Tick>
                <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
                  {[['training','Training'],['automation','Automation'],['other','Other']].map(([k,l]) => (
                    <button key={k} onClick={() => update('topic', k)} style={{
                      background: form.topic === k ? 'var(--ink)' : 'transparent',
                      color: form.topic === k ? 'var(--paper)' : 'var(--ink)',
                      border: '1px solid ' + (form.topic === k ? 'var(--ink)' : 'var(--rule)'),
                      padding: '6px 12px', cursor: 'pointer',
                      fontFamily: 'var(--mono)', fontSize: 10, fontWeight: 500,
                      letterSpacing: 1.2, textTransform: 'uppercase',
                    }}>{l}</button>
                  ))}
                </div>
              </div>
              <div style={{ padding: '14px 0', borderBottom: '1px solid var(--rule)' }}>
                <Tick style={{ display: 'block', marginBottom: 8 }}>Note</Tick>
                <textarea value={form.note} onChange={e => update('note', e.target.value)}
                  rows={4}
                  placeholder="What are you trying to automate?"
                  style={{
                    width: '100%', background: 'transparent', border: 'none',
                    fontFamily: 'var(--sans)', fontSize: 15, color: 'var(--ink)',
                    outline: 'none', resize: 'vertical', padding: 0,
                  }}/>
              </div>
              <button onClick={() => valid && setSent(true)}
                disabled={!valid}
                style={{
                  marginTop: 20, padding: '14px 20px',
                  background: valid ? 'var(--ink)' : 'transparent',
                  color: valid ? 'var(--paper)' : 'var(--muted)',
                  border: '1px solid ' + (valid ? 'var(--ink)' : 'var(--rule)'),
                  fontFamily: 'var(--mono)', fontSize: 11, letterSpacing: 1.4,
                  textTransform: 'uppercase', cursor: valid ? 'pointer' : 'not-allowed',
                  width: '100%', fontWeight: 500,
                }}>
                Send message →
              </button>
            </div>
          )}
        </div>
      </section>
    </>
  );
}

function FormField({ label, value, onChange, type = 'text' }) {
  return (
    <div style={{
      padding: '14px 0', borderBottom: '1px solid var(--rule)',
      display: 'grid', gridTemplateColumns: '80px 1fr', alignItems: 'center', gap: 12,
    }}>
      <Tick>{label}</Tick>
      <input type={type} value={value} onChange={e => onChange(e.target.value)}
        style={{
          background: 'transparent', border: 'none',
          fontFamily: 'var(--sans)', fontSize: 16, color: 'var(--ink)',
          outline: 'none', padding: 0,
        }}/>
    </div>
  );
}

Object.assign(window, { Classes, Writing, About, Contact });
