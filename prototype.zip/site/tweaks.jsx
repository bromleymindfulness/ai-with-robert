// Tweaks panel

function TweaksPanel({ tweaks, setTweaks, visible }) {
  const [tab, setTab] = React.useState('look');

  if (!visible) return null;

  const persist = (patch) => {
    setTweaks(t => ({ ...t, ...patch }));
    try {
      window.parent.postMessage({ type: '__edit_mode_set_keys', edits: patch }, '*');
    } catch (e) {}
  };

  const applyPalette = (name) => persist({ ...PALETTES[name], darkMode: name === 'dark' });

  return (
    <div style={{
      position: 'fixed', bottom: 16, right: 16, zIndex: 200,
      width: 'min(360px, calc(100vw - 32px))',
      maxHeight: 'calc(100vh - 32px)',
      background: '#0b1620', color: '#eef1f4',
      border: '1px solid rgba(255,255,255,0.15)',
      boxShadow: '0 20px 60px rgba(0,0,0,0.4)',
      fontFamily: '"JetBrains Mono", ui-monospace, monospace',
      display: 'flex', flexDirection: 'column',
    }}>
      <div style={{
        padding: '14px 16px', borderBottom: '1px solid rgba(255,255,255,0.12)',
        display: 'flex', justifyContent: 'space-between', alignItems: 'center',
      }}>
        <span style={{ fontSize: 11, letterSpacing: 1.6, textTransform: 'uppercase', fontWeight: 600 }}>Tweaks</span>
        <span style={{ fontSize: 10, letterSpacing: 1.2, color: 'rgba(255,255,255,0.5)' }}>
          Robert Mitchell · v1
        </span>
      </div>

      <div style={{
        display: 'flex', borderBottom: '1px solid rgba(255,255,255,0.12)',
      }}>
        {['look', 'type', 'copy', 'layout'].map(t => (
          <button key={t} onClick={() => setTab(t)} style={{
            flex: 1, background: tab === t ? 'rgba(255,255,255,0.08)' : 'transparent',
            color: tab === t ? '#fff' : 'rgba(255,255,255,0.6)',
            border: 'none', padding: '10px 0',
            fontFamily: 'inherit', fontSize: 10,
            letterSpacing: 1.4, textTransform: 'uppercase', cursor: 'pointer',
          }}>{t}</button>
        ))}
      </div>

      <div style={{ padding: '16px', overflowY: 'auto', flex: 1, fontSize: 12 }}>
        {tab === 'look' && (
          <>
            <Label>Palette</Label>
            <div style={{
              display: 'grid', gridTemplateColumns: 'repeat(5, 1fr)',
              gap: 6, marginBottom: 20,
            }}>
              {Object.entries(PALETTES).map(([name, p]) => {
                const isActive = tweaks.accent === p.accent && tweaks.paper === p.paper;
                return (
                  <button key={name} onClick={() => applyPalette(name)} title={name}
                    style={{
                      padding: 0, border: '1px solid ' + (isActive ? '#fff' : 'rgba(255,255,255,0.2)'),
                      background: p.paper, cursor: 'pointer',
                      height: 40, display: 'flex', flexDirection: 'column',
                    }}>
                    <div style={{ flex: 1, background: p.paper }}/>
                    <div style={{ flex: 1, background: p.ink }}/>
                    <div style={{ height: 5, background: p.accent }}/>
                  </button>
                );
              })}
            </div>

            <Label>Accent</Label>
            <input type="color" value={tweaks.accent}
              onChange={e => persist({ accent: e.target.value })}
              style={{ width: '100%', height: 32, border: 'none', background: 'transparent', padding: 0, marginBottom: 16 }}/>

            <Label>Dark mode</Label>
            <Toggle value={tweaks.darkMode} onChange={v => {
              if (v) applyPalette('dark');
              else applyPalette('slate');
            }}/>
          </>
        )}

        {tab === 'type' && (
          <>
            <Label>Display font</Label>
            <Select value={tweaks.displayFont} onChange={v => persist({ displayFont: v })}
              options={['JetBrains Mono', 'IBM Plex Mono', 'Space Mono', 'DM Mono', 'Geist Mono']}/>
            <div style={{ height: 16 }}/>
            <Label>Mono font</Label>
            <Select value={tweaks.monoFont} onChange={v => persist({ monoFont: v })}
              options={['JetBrains Mono', 'IBM Plex Mono', 'Space Mono', 'DM Mono', 'Geist Mono']}/>
            <div style={{
              marginTop: 22, padding: 16,
              background: 'rgba(255,255,255,0.06)',
            }}>
              <div style={{
                fontFamily: `"${tweaks.displayFont}", serif`, fontSize: 24,
                letterSpacing: -0.5, lineHeight: 1.1,
              }}>Preview display</div>
              <div style={{
                fontFamily: `"${tweaks.monoFont}", monospace`,
                fontSize: 10, letterSpacing: 1.4, textTransform: 'uppercase',
                marginTop: 8, color: 'rgba(255,255,255,0.6)',
              }}>Preview · mono label</div>
            </div>
          </>
        )}

        {tab === 'copy' && (
          <>
            <Label>Hero headline</Label>
            <TextArea value={tweaks.heroHeadline} onChange={v => persist({ heroHeadline: v })} rows={3}/>
            <div style={{ height: 16 }}/>
            <Label>Hero subline</Label>
            <TextArea value={tweaks.heroSub} onChange={v => persist({ heroSub: v })} rows={4}/>
            <div style={{ height: 16 }}/>
            <Label>CTA label</Label>
            <TextInput value={tweaks.ctaLabel} onChange={v => persist({ ctaLabel: v })}/>
          </>
        )}

        {tab === 'layout' && (
          <>
            <Label>Hero style</Label>
            <SegBtn value={tweaks.heroVariant} onChange={v => persist({ heroVariant: v })}
              options={[['standard','Standard'],['italic','Italic']]}/>
            <div style={{ height: 16 }}/>
            <Label>Services layout</Label>
            <SegBtn value={tweaks.servicesLayout} onChange={v => persist({ servicesLayout: v })}
              options={[['list','List'],['grid','Grid']]}/>
          </>
        )}
      </div>
    </div>
  );
}

function Label({ children }) {
  return <div style={{
    fontSize: 9, letterSpacing: 1.6, textTransform: 'uppercase',
    color: 'rgba(255,255,255,0.5)', marginBottom: 8, fontWeight: 500,
  }}>{children}</div>;
}

function Toggle({ value, onChange }) {
  return (
    <button onClick={() => onChange(!value)} style={{
      width: 40, height: 22, borderRadius: 11, border: 'none',
      background: value ? '#6fa3d9' : 'rgba(255,255,255,0.2)',
      position: 'relative', cursor: 'pointer', padding: 0,
    }}>
      <span style={{
        position: 'absolute', top: 2, left: value ? 20 : 2,
        width: 18, height: 18, borderRadius: '50%', background: '#fff',
        transition: 'left 150ms',
      }}/>
    </button>
  );
}

function Select({ value, onChange, options }) {
  return (
    <select value={value} onChange={e => onChange(e.target.value)}
      style={{
        width: '100%', padding: '8px 10px',
        background: 'rgba(255,255,255,0.06)', color: '#fff',
        border: '1px solid rgba(255,255,255,0.15)',
        fontFamily: 'inherit', fontSize: 12, outline: 'none',
      }}>
      {options.map(o => <option key={o} value={o} style={{ background: '#0b1620' }}>{o}</option>)}
    </select>
  );
}

function TextInput({ value, onChange }) {
  return (
    <input value={value} onChange={e => onChange(e.target.value)}
      style={{
        width: '100%', padding: '8px 10px',
        background: 'rgba(255,255,255,0.06)', color: '#fff',
        border: '1px solid rgba(255,255,255,0.15)',
        fontFamily: 'inherit', fontSize: 12, outline: 'none',
      }}/>
  );
}

function TextArea({ value, onChange, rows = 3 }) {
  return (
    <textarea value={value} onChange={e => onChange(e.target.value)} rows={rows}
      style={{
        width: '100%', padding: '8px 10px',
        background: 'rgba(255,255,255,0.06)', color: '#fff',
        border: '1px solid rgba(255,255,255,0.15)',
        fontFamily: 'inherit', fontSize: 12, outline: 'none',
        resize: 'vertical', lineHeight: 1.5,
      }}/>
  );
}

function SegBtn({ value, onChange, options }) {
  return (
    <div style={{ display: 'flex', border: '1px solid rgba(255,255,255,0.15)' }}>
      {options.map(([k, l]) => (
        <button key={k} onClick={() => onChange(k)} style={{
          flex: 1, background: value === k ? 'rgba(255,255,255,0.15)' : 'transparent',
          color: value === k ? '#fff' : 'rgba(255,255,255,0.6)',
          border: 'none', padding: '8px 0', cursor: 'pointer',
          fontFamily: 'inherit', fontSize: 10, letterSpacing: 1.4,
          textTransform: 'uppercase',
        }}>{l}</button>
      ))}
    </div>
  );
}

Object.assign(window, { TweaksPanel });
