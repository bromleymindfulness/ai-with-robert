// Direction C — Quiet Editorial
// Big generous serif, pale blue washes, very "New Yorker online" feel
// Warmer & more human than A, less dense than B

function DirectionC({ width = 390 }) {
  const ink = '#14263b';
  const paper = '#fbfcfd';
  const wash = '#e6ecf3';
  const blue = '#3c6a9a';
  const muted = '#6a7684';
  const rule = 'rgba(20,38,59,0.14)';

  return (
    <div style={{
      width, minHeight: 844, background: paper, color: ink,
      fontFamily: '"Geist", -apple-system, system-ui, sans-serif',
      fontSize: 15,
    }}>
      {/* Nav */}
      <div style={{
        padding: '18px 24px', display: 'flex', justifyContent: 'space-between',
        alignItems: 'center',
      }}>
        <span style={{
          fontFamily: '"Instrument Serif", serif', fontSize: 22, fontStyle: 'italic',
          letterSpacing: -0.5,
        }}>Robert Mitchell</span>
        <span style={{
          width: 24, height: 12,
          display: 'flex', flexDirection: 'column', justifyContent: 'space-between',
        }}>
          <span style={{ height: 1, background: ink }}/>
          <span style={{ height: 1, background: ink }}/>
        </span>
      </div>

      {/* Hero with blue wash */}
      <div style={{ background: wash, padding: '44px 24px 52px', position: 'relative' }}>
        <div style={{
          fontFamily: '"JetBrains Mono", monospace', fontSize: 10,
          letterSpacing: 1.6, textTransform: 'uppercase', color: blue,
          marginBottom: 24,
        }}>
          Essay · Services · Live
        </div>
        <h1 style={{
          fontFamily: '"Instrument Serif", serif',
          fontSize: 46, lineHeight: 1.0, letterSpacing: -1.5,
          fontWeight: 400, margin: 0, textWrap: 'pretty',
        }}>
          A small<br/>
          <em style={{ color: blue }}>team</em> of<br/>
          specialists,<br/>
          inside your<br/>
          Telegram.
        </h1>
        <p style={{
          marginTop: 28, fontSize: 15, lineHeight: 1.6, color: '#35485e',
          maxWidth: 320,
        }}>
          Content, ads, SEO, email, analytics — running
          twenty-four hours, for less than the cost of one
          junior hire.
        </p>
      </div>

      {/* CTA card */}
      <div style={{
        margin: '-20px 24px 0', background: paper,
        boxShadow: '0 6px 24px rgba(20,38,59,0.08)',
        padding: '22px 22px 20px', borderRadius: 2,
        border: `1px solid ${rule}`, position: 'relative', zIndex: 2,
      }}>
        <div style={{
          fontFamily: '"JetBrains Mono", monospace', fontSize: 10,
          letterSpacing: 1.4, textTransform: 'uppercase', color: muted,
        }}>
          Next live class
        </div>
        <div style={{
          fontFamily: '"Instrument Serif", serif', fontSize: 22,
          lineHeight: 1.15, marginTop: 6, letterSpacing: -0.3,
        }}>
          Deploying your first<br/>Telegram bot team
        </div>
        <div style={{
          marginTop: 6, fontSize: 13, color: muted,
        }}>Thu 23 Apr · 18:00 GMT · YouTube Live</div>
        <div style={{
          marginTop: 18,
          display: 'flex', gap: 10,
        }}>
          <input placeholder="you@domain.com" style={{
            flex: 1, padding: '12px 14px', border: `1px solid ${rule}`,
            borderRadius: 2, fontSize: 14, background: paper,
            fontFamily: 'inherit', color: ink, outline: 'none',
          }}/>
          <button style={{
            padding: '12px 16px', background: ink, color: paper,
            border: 'none', borderRadius: 2, fontSize: 13,
            fontFamily: 'inherit', letterSpacing: 0.2, cursor: 'pointer',
          }}>
            Save seat
          </button>
        </div>
      </div>

      {/* Services */}
      <div style={{ padding: '56px 24px 36px' }}>
        <div style={{
          fontFamily: '"JetBrains Mono", monospace', fontSize: 10,
          letterSpacing: 1.6, textTransform: 'uppercase', color: muted,
          marginBottom: 22,
        }}>
          What I do
        </div>
        {[
          { t: 'AI Automation Training', d: 'Small cohorts. Live on YouTube. Build your own bot team, end-to-end, across six weeks.' },
          { t: 'AI Marketing Automation', d: 'I deploy and run a team of bots in your Telegram — content, ads, SEO, email, analytics.' },
        ].map((s, i) => (
          <div key={i} style={{
            padding: '24px 0', borderTop: `1px solid ${rule}`,
            borderBottom: i === 1 ? `1px solid ${rule}` : 'none',
          }}>
            <div style={{
              fontFamily: '"Instrument Serif", serif', fontSize: 26,
              lineHeight: 1.1, letterSpacing: -0.5, marginBottom: 8,
            }}>{s.t}</div>
            <div style={{ fontSize: 14, color: '#3d4c5e', lineHeight: 1.55, textWrap: 'pretty' }}>
              {s.d}
            </div>
            <div style={{
              marginTop: 14, fontFamily: '"JetBrains Mono", monospace',
              fontSize: 11, letterSpacing: 1.4, textTransform: 'uppercase',
              color: blue,
            }}>Read more →</div>
          </div>
        ))}
      </div>

      {/* Writing */}
      <div style={{ padding: '16px 24px 44px' }}>
        <div style={{
          display: 'flex', justifyContent: 'space-between', alignItems: 'baseline',
          marginBottom: 18,
        }}>
          <span style={{
            fontFamily: '"Instrument Serif", serif', fontSize: 26, letterSpacing: -0.4,
          }}>Writing</span>
          <span style={{
            fontFamily: '"JetBrains Mono", monospace', fontSize: 10,
            letterSpacing: 1.4, textTransform: 'uppercase', color: muted,
          }}>All →</span>
        </div>

        {[
          { t: 'Why 20 small bots beat one big agent', d: 'Apr 18 · 6 min', tag: 'Essay' },
          { t: 'The Telegram-first marketing stack', d: 'Apr 11 · 9 min', tag: 'Playbook' },
          { t: 'Memory, tools, and the cost of context', d: 'Apr 04 · 5 min', tag: 'Note' },
        ].map((p, i) => (
          <div key={i} style={{
            padding: '18px 0',
            borderTop: `1px solid ${rule}`,
          }}>
            <div style={{
              fontFamily: '"JetBrains Mono", monospace', fontSize: 9,
              letterSpacing: 1.6, textTransform: 'uppercase', color: blue,
              marginBottom: 6,
            }}>{p.tag}</div>
            <div style={{
              fontFamily: '"Instrument Serif", serif', fontSize: 20,
              lineHeight: 1.15, letterSpacing: -0.3, textWrap: 'pretty',
            }}>{p.t}</div>
            <div style={{ marginTop: 8, fontSize: 12, color: muted }}>{p.d}</div>
          </div>
        ))}
      </div>

      {/* Footer */}
      <div style={{
        padding: '28px 24px', background: wash, color: muted,
        fontSize: 12,
      }}>
        <div style={{
          fontFamily: '"Instrument Serif", serif', fontSize: 30,
          fontStyle: 'italic', color: ink, letterSpacing: -0.8,
          marginBottom: 20, lineHeight: 1,
        }}>Robert Mitchell</div>
        <div style={{ display: 'flex', gap: 16, fontFamily: '"JetBrains Mono", monospace', fontSize: 10, letterSpacing: 1.4, textTransform: 'uppercase' }}>
          <span>Telegram</span><span>YouTube</span><span>Contact</span>
        </div>
        <div style={{ marginTop: 24, fontSize: 11 }}>© 2026 R.M.</div>
      </div>
    </div>
  );
}

window.DirectionC = DirectionC;
