// Home + Services pages — all-mono display

function Home({ tokens, tweaks, onRoute, onEmailCapture }) {
  const [email, setEmail] = React.useState('');
  const [captured, setCaptured] = React.useState(false);

  const submit = () => {
    if (!/.+@.+\..+/.test(email)) return;
    setCaptured(true);
    onEmailCapture && onEmailCapture(email);
  };

  const next = UPCOMING_CLASSES[0];

  return (
    <>
      {/* Title block */}
      <section style={{ padding: 'clamp(48px, 9vw, 104px) clamp(20px, 4vw, 56px) clamp(36px, 6vw, 60px)' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 'clamp(28px, 5vw, 40px)' }}>
          <Tick>Document / 001 / Index</Tick>
          <Tick>20 Apr 2026</Tick>
        </div>
        <h1 style={{
          fontFamily: 'var(--display)',
          fontSize: 'clamp(28px, 5.4vw, 64px)',
          lineHeight: 1.05, letterSpacing: '-0.04em',
          fontWeight: 500, margin: 0,
          textWrap: 'balance', color: 'var(--ink)',
          textTransform: tweaks.heroVariant === 'italic' ? 'none' : 'uppercase',
          fontStyle: tweaks.heroVariant === 'italic' ? 'italic' : 'normal',
        }}>
          {tweaks.heroHeadline}
        </h1>
        <p style={{
          marginTop: 'clamp(20px, 3vw, 32px)',
          fontFamily: 'var(--sans)',
          fontSize: 'clamp(15px, 1.6vw, 18px)',
          lineHeight: 1.55, color: 'var(--subtle)',
          maxWidth: 560, textWrap: 'pretty',
        }}>
          {tweaks.heroSub}
        </p>
      </section>

      {/* Spec */}
      <section style={{ padding: '0 clamp(20px, 4vw, 56px) clamp(36px, 6vw, 60px)' }}>
        <SpecRow l="Client"  r="You"/>
        <SpecRow l="Fleet"   r="20 bots / server"/>
        <SpecRow l="Channel" r="Telegram"/>
        <SpecRow l="Uptime"  r="24 / 7"/>
        <SpecRow l="Cost"    r="< 1 junior hire"/>
      </section>

      {/* Services shortcut */}
      <section style={{ padding: '0 clamp(20px, 4vw, 56px) clamp(36px, 6vw, 60px)' }}>
        <SectionHeader num="02" label="Services" right="Two streams"/>
        <div style={{
          display: 'grid', gap: 'clamp(14px, 2vw, 20px)',
          gridTemplateColumns: 'repeat(auto-fit, minmax(260px, 1fr))',
        }}>
          {[
            { k: 'A', t: 'Training', d: 'Learn to design, build and ship your own bot team. Small cohorts, live on YouTube.', href: 'services' },
            { k: 'B', t: 'Automation', d: 'I deploy and operate a team of specialist bots inside your Telegram. Done-for-you.', href: 'services' },
          ].map(s => (
            <a key={s.k}
              href="#"
              onClick={e => { e.preventDefault(); onRoute(s.href); }}
              style={{
                display: 'block', padding: 'clamp(22px, 3vw, 28px) clamp(20px, 2.5vw, 26px)',
                border: '1px solid var(--rule)',
                background: 'var(--panel)',
                textDecoration: 'none', color: 'inherit',
                transition: 'border-color 150ms, transform 150ms',
              }}
              onMouseEnter={e => { e.currentTarget.style.borderColor = 'var(--accent)'; }}
              onMouseLeave={e => { e.currentTarget.style.borderColor = 'var(--rule)'; }}
            >
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 18 }}>
                <Tick color="var(--accent)">— {s.k}</Tick>
                <Tick>→</Tick>
              </div>
              <div style={{
                fontFamily: 'var(--display)',
                fontSize: 'clamp(20px, 2vw, 26px)', lineHeight: 1.1,
                letterSpacing: '-0.03em', fontWeight: 500,
                textTransform: 'uppercase',
                marginBottom: 10, color: 'var(--ink)',
              }}>{s.t}</div>
              <div style={{
                fontFamily: 'var(--sans)', fontSize: 14, lineHeight: 1.55,
                color: 'var(--subtle)', textWrap: 'pretty',
              }}>{s.d}</div>
            </a>
          ))}
        </div>
      </section>

      {/* Live CTA */}
      <section style={{ padding: '0 clamp(20px, 4vw, 56px) clamp(36px, 6vw, 60px)' }}>
        <InvertBlock style={{ padding: 'clamp(28px, 4vw, 44px)' }}>
          <div style={{
            display: 'flex', justifyContent: 'space-between', alignItems: 'center',
            marginBottom: 20,
          }}>
            <Tick color="rgba(255,255,255,0.6)">Next live · YouTube</Tick>
            <Tick color="rgba(255,255,255,0.6)">{next.dateShort}</Tick>
          </div>
          <div style={{
            fontFamily: 'var(--display)',
            fontSize: 'clamp(20px, 2.6vw, 30px)',
            lineHeight: 1.15, letterSpacing: '-0.03em', fontWeight: 500,
            marginBottom: 22, textWrap: 'balance', maxWidth: 620,
          }}>
            {next.title}
          </div>
          <div style={{
            display: 'flex', gap: 8, marginBottom: 26, flexWrap: 'wrap',
            fontFamily: 'var(--mono)', fontSize: 11, letterSpacing: 1.2,
            textTransform: 'uppercase', color: 'rgba(255,255,255,0.65)',
          }}>
            <span>{next.date}</span><span>·</span><span>{next.duration}</span>
          </div>

          {captured ? (
            <div style={{
              padding: '14px 0', borderTop: '1px solid rgba(255,255,255,0.3)',
              borderBottom: '1px solid rgba(255,255,255,0.3)',
              fontFamily: 'var(--mono)', fontSize: 12, letterSpacing: 0.4,
              color: 'var(--paper)',
            }}>
              ✓ Seat saved. Calendar invite on the way to <b>{email}</b>.
            </div>
          ) : (
            <div style={{ maxWidth: 460 }}>
              <UnderlineInput
                value={email}
                onChange={setEmail}
                placeholder="you@domain.com"
                inverted
                onSubmit={submit}
                cta={`${tweaks.ctaLabel} →`}
              />
            </div>
          )}
        </InvertBlock>
      </section>

      {/* Writing */}
      <section style={{ padding: '0 clamp(20px, 4vw, 56px) clamp(40px, 7vw, 72px)' }}>
        <SectionHeader num="03" label="Writing" right={<a href="#" onClick={e => { e.preventDefault(); onRoute('writing'); }} style={{ color: 'var(--ink)', textDecoration: 'none', fontFamily: 'var(--mono)', fontSize: 10, letterSpacing: 1.4, textTransform: 'uppercase' }}>All →</a>}/>
        {POSTS.slice(0, 3).map(p => (
          <a key={p.id} href="#" onClick={e => { e.preventDefault(); onRoute('writing'); }}
            style={{
              display: 'grid',
              gridTemplateColumns: 'clamp(48px, 7vw, 72px) 1fr auto',
              gap: 'clamp(12px, 2vw, 24px)', alignItems: 'baseline',
              padding: '18px 0', borderBottom: '1px solid var(--rule)',
              textDecoration: 'none', color: 'inherit',
              transition: 'padding 160ms',
            }}
            onMouseEnter={e => e.currentTarget.style.paddingLeft = '10px'}
            onMouseLeave={e => e.currentTarget.style.paddingLeft = '0'}
          >
            <Tick color="var(--accent)">{p.num}</Tick>
            <div style={{
              fontFamily: 'var(--sans)',
              fontSize: 'clamp(15px, 1.6vw, 17px)',
              lineHeight: 1.35, color: 'var(--ink)',
            }}>{p.title}</div>
            <Tick>{p.date}</Tick>
          </a>
        ))}
      </section>
    </>
  );
}

function Services({ tokens, tweaks, onRoute }) {
  const layout = tweaks.servicesLayout;

  const services = [
    {
      k: 'A',
      kind: 'Training',
      title: 'AI Automation Training',
      price: '£1,200 / cohort',
      lede: 'A six-week, live-on-YouTube cohort. You leave with a working team of bots, deployed to your own Telegram.',
      bullets: [
        'Six 60-minute live classes',
        'One-to-one review session',
        'Private Telegram cohort group',
        'Written versions of every class',
        'Code, prompts, and server recipes',
      ],
    },
    {
      k: 'B',
      kind: 'Automation',
      title: 'AI Marketing Automation',
      price: 'From £2,500 / mo',
      lede: 'I deploy and operate a team of specialist bots — content, ads, SEO, email, analytics — inside your Telegram. You talk to them. They do the work.',
      bullets: [
        'Five to twenty bots, tuned to your business',
        'Hosted on my Nanoclaw fleet',
        'Weekly reporting inside Telegram',
        'Monthly tuning & retraining',
        'Cancel monthly, no contract',
      ],
    },
  ];

  return (
    <>
      <section style={{ padding: 'clamp(48px, 8vw, 84px) clamp(20px, 4vw, 56px) clamp(28px, 4vw, 40px)' }}>
        <Tick style={{ marginBottom: 24, display: 'block' }}>Document / 002 / Services</Tick>
        <h1 style={{
          fontFamily: 'var(--display)',
          fontSize: 'clamp(32px, 5.5vw, 64px)',
          lineHeight: 1.0, letterSpacing: '-0.04em',
          fontWeight: 500, margin: 0, textTransform: 'uppercase',
          textWrap: 'balance', color: 'var(--ink)',
        }}>
          Two streams.<br/>Same stack.
        </h1>
        <p style={{
          marginTop: 24, fontFamily: 'var(--sans)',
          fontSize: 'clamp(15px, 1.6vw, 18px)', lineHeight: 1.55,
          color: 'var(--subtle)', maxWidth: 560, textWrap: 'pretty',
        }}>
          Teach the team to build it, or let me run it for you.
          Either way, the deliverable is the same: a room full of specialist bots inside your Telegram.
        </p>
      </section>

      <section style={{
        padding: '0 clamp(20px, 4vw, 56px) clamp(40px, 7vw, 72px)',
        display: 'grid',
        gridTemplateColumns: layout === 'grid' ? 'repeat(auto-fit, minmax(340px, 1fr))' : '1fr',
        gap: layout === 'grid' ? 'clamp(20px, 3vw, 28px)' : 0,
      }}>
        {services.map((s, i) => (
          <div key={s.k} style={{
            borderTop: '1px solid var(--rule)',
            borderBottom: (layout === 'list' && i === services.length - 1) ? '1px solid var(--rule)' : 'none',
            borderInline: layout === 'grid' ? '1px solid var(--rule)' : 'none',
            borderBottomColor: layout === 'grid' ? 'var(--rule)' : undefined,
            borderBottomStyle: layout === 'grid' ? 'solid' : undefined,
            borderBottomWidth: layout === 'grid' ? 1 : undefined,
            background: layout === 'grid' ? 'var(--panel)' : 'transparent',
            padding: layout === 'grid' ? 'clamp(28px, 3vw, 36px)' : 'clamp(28px, 4vw, 44px) 0',
            display: 'grid',
            gridTemplateColumns: 'clamp(32px, 4vw, 56px) 1fr',
            gap: 'clamp(12px, 2vw, 24px)',
          }}>
            <div>
              <Tick color="var(--accent)">— {s.k}</Tick>
            </div>
            <div>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', marginBottom: 8 }}>
                <Tick>{s.kind}</Tick>
                <Tick>{s.price}</Tick>
              </div>
              <h2 style={{
                fontFamily: 'var(--display)',
                fontSize: 'clamp(22px, 2.8vw, 32px)',
                lineHeight: 1.05, letterSpacing: '-0.04em', fontWeight: 500,
                textTransform: 'uppercase',
                margin: '8px 0 16px', color: 'var(--ink)', textWrap: 'balance',
              }}>{s.title}</h2>
              <p style={{
                fontFamily: 'var(--sans)',
                fontSize: 'clamp(15px, 1.6vw, 17px)', lineHeight: 1.55,
                color: 'var(--subtle)', maxWidth: 520, textWrap: 'pretty',
                marginTop: 0,
              }}>{s.lede}</p>

              <ul style={{
                listStyle: 'none', padding: 0, margin: '22px 0 24px',
              }}>
                {s.bullets.map(b => (
                  <li key={b} style={{
                    display: 'grid', gridTemplateColumns: '16px 1fr', gap: 10,
                    alignItems: 'baseline',
                    padding: '8px 0',
                    fontFamily: 'var(--sans)', fontSize: 14,
                    color: 'var(--ink)',
                  }}>
                    <span style={{ color: 'var(--accent)', fontFamily: 'var(--mono)', fontSize: 11 }}>✓</span>
                    <span>{b}</span>
                  </li>
                ))}
              </ul>

              <TextLink color="var(--accent)" onClick={() => onRoute('contact')}>
                Enquire → {s.kind}
              </TextLink>
            </div>
          </div>
        ))}
      </section>
    </>
  );
}

Object.assign(window, { Home, Services });
