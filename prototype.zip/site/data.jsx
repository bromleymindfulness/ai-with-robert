// Seed data for classes + posts

const UPCOMING_CLASSES = [
  {
    id: 'c-001',
    num: '0.01',
    title: 'Deploying your first Telegram bot team',
    date: 'Thu 23 Apr · 18:00 GMT',
    dateShort: '23 Apr',
    duration: '60 min',
    tag: 'Live',
    abstract: 'From zero to a five-bot team inside your Telegram group. We build, deploy, and hand over control in one session.',
    status: 'upcoming',
  },
  {
    id: 'c-002',
    num: '0.02',
    title: 'Memory, tools, and the cost of context',
    date: 'Thu 30 Apr · 18:00 GMT',
    dateShort: '30 Apr',
    duration: '60 min',
    tag: 'Live',
    abstract: 'How to stop paying for context you don\'t need. Trimming, summarisation, and per-bot memory scopes.',
    status: 'upcoming',
  },
  {
    id: 'c-003',
    num: '0.03',
    title: 'Selling to one message at a time',
    date: 'Thu 07 May · 18:00 GMT',
    dateShort: '07 May',
    duration: '60 min',
    tag: 'Live',
    abstract: 'Messaging-first funnels. Why DM-native outperforms landing pages for certain niches.',
    status: 'upcoming',
  },
];

const PAST_CLASSES = [
  { id: 'p-001', num: '0.00', title: 'Why 20 small bots beat one big agent', dateShort: '18 Apr', duration: '54 min' },
  { id: 'p-002', num: '0.-1', title: 'The Telegram-first marketing stack', dateShort: '11 Apr', duration: '47 min' },
  { id: 'p-003', num: '0.-2', title: 'Cold start: your first lead pipeline', dateShort: '04 Apr', duration: '62 min' },
];

const POSTS = [
  { id: 'w-01', num: '0.04', tag: 'Essay', title: 'Why 20 small bots beat one big agent', date: 'Apr 18', read: '6 min', excerpt: 'A single agent with infinite context is the wrong mental model. Here\'s what you get when you break it up.' },
  { id: 'w-02', num: '0.03', tag: 'Playbook', title: 'The Telegram-first marketing stack', date: 'Apr 11', read: '9 min', excerpt: 'Every piece of the stack I run, why it\'s on Telegram, and what it costs per month.' },
  { id: 'w-03', num: '0.02', tag: 'Note', title: 'Memory, tools, and the cost of context', date: 'Apr 04', read: '5 min', excerpt: 'Most of your token bill is the assistant re-reading things it already knew. Here\'s how to stop that.' },
  { id: 'w-04', num: '0.01', tag: 'Essay', title: 'The junior hire vs the bot team', date: 'Mar 28', read: '7 min', excerpt: 'A fair comparison of what a £35k/yr hire actually delivers vs a 20-bot fleet.' },
  { id: 'w-05', num: '0.00', tag: 'Note', title: 'Local networking, in 2026', date: 'Mar 21', read: '4 min', excerpt: 'Why meeting 15 people in a pub still beats the feed algorithm.' },
];

Object.assign(window, { UPCOMING_CLASSES, PAST_CLASSES, POSTS });
